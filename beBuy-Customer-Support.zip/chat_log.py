import os
from datetime import datetime

def chat(name, msg, file='logs/chlog.txt'):
    os.makedirs(os.path.dirname(file), exist_ok=True)
    time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    with open(file, 'a') as f:
        f.write(f"[{time}] {name}: {msg}\n")
