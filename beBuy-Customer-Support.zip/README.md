# beBuy Customer Support Automation

A sleek, lightweight customer support system for beBuy — featuring:

- Telegram bot that responds to customer order queries 
- Logs interactions and chat transcripts automatically 
- Generates neat PDF reports summarizing support data 
- Simple GUI to manage reports and start the bot 
- CRM integration to match orders with customer names

---

## Features

- Easy customer support via Telegram 
- Automatic logging for transparency and tracking 
- PDF report generation for quick insights 
- Expandable & modular Python scripts 
- Minimal dependencies: python-telegram-bot, fpdf, tkinter

---

## How to Run

1. Clone the repo 
2. Create and fill crm.csv with your orders and customer names
3. Install dependencies: 
```bash
pip install python-telegram-bot==13.15 fpdf
