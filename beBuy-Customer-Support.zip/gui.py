import tkinter as tk
from tkinter import messagebox
import subprocess
from report_gen import make_report

def start_bot():
    try:
        subprocess.Popen(["python3", "bot.py"])
        messagebox.showinfo("Bot", "Telegram bot started ")
    except Exception as e:
        messagebox.showerror("Error", f"Start bot failed: {e}")

def make_pdf():
    try:
        make_report()
        messagebox.showinfo("PDF", "Report created ")
    except Exception as e:
        messagebox.showerror("Error", f"PDF error: {e}")

root = tk.Tk()
root.title("beBuy Panel")

tk.Label(root, text="beBuy Support Panel", font=("Arial", 16)).pack(pady=10)
tk.Button(root, text="Start Bot", command=start_bot).pack(pady=5)
tk.Button(root, text="Make PDF", command=make_pdf).pack(pady=5)

root.mainloop()
