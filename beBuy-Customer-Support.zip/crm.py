import csv

def load(file='crm.csv'):
    data = {}
    try:
        with open(file, newline='') as f:
            r = csv.DictReader(f)
            for row in r:
                data[row['order_id']] = row['customer_name']
    except FileNotFoundError:
        print(f"{file} not found.")
    return data

def get_name(oid, data):
    return data.get(oid, "Unknown")
