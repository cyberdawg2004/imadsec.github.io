import logging
import os

if not os.path.exists('logs'):
    os.makedirs('logs')

logging.basicConfig(filename='logs/slog.txt', level=logging.INFO)

def log(name, oid, cat, act, rate):
    logging.info(f"{name},{oid},{cat},{act},{rate}")
