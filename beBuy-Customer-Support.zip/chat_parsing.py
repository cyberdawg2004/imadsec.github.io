import re
from support_logger import log_interaction

def parse_chat(file_path):
	with open(file_path, 'r') as file:
		lines= file.readlines()

	interaction_blocks= []
	current_block= []

	for line in lines:
		if line.strip() == "":
			if current_block:
				interaction_blocks.append(current_block)
				current_block= []
		else:
			current_block.append(line.strip())
	if current_block:
		interaction_blocks.append(current_block)
	for block in interaction_blocks:
		customerline = block[0]
		actionline= block[1] if len(block) > 1 else "Support: No action recorded"
		match = re.match(r"\[\d{2}:\d{2}\] (.+) \((BBY\d+): (.+)", customerline)
		if match:
			name= match.group(1)
			orderID= match.group(2)
			issueText= match.group(3)
			action= actionline.split("Support: ")[-1].strip()
			category= "Delivery Delay" if "package" in issueText.lower() else "Product Issue"
			score= 5

			log_interaction(name, orderID, category, action, score)
