import dash
from dash import html, dcc
import pandas as pd

app = dash.Dash(__name__)

def load_data():
    df = pd.read_csv('interactions.csv', names=['Name','Order ID','Category','Action Taken','Score'])
    return df

app.layout = html.Div(children=[
    html.H1(children='beBuy Support Dashboard'),
    dcc.Graph(
        id='category-graph',
        figure={
            'data': [
                {
                  'x': load_data()['Category'].value_counts().index,
                  'y': load_data()['Category'].value_counts().values,
                  'type': 'bar'
                }
            ],
            'layout': {'title': 'Issues by Category'}
        }
    )
])

if name == '__main__':
    app.run_server(debug=True)
