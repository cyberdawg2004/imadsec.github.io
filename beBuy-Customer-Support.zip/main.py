from support_logger import log_interaction
from chat_parsing import parse_chat

while True:
	print("\nbeBuy - Customer Interaction Logger\n1. Log New Support Interaction\n2. Parse SMS/Chat Log\n3. Exit")
	choice= input("Enter your choice: ")

	if choice == '1':
		name= input("Customer Name: ")
		order= input("Order ID: ")
		print("Issue Types: Refund, Delivery Delay, Return, Product Issue, General Question")
		issue= input("Select Issue Type: ")
		action= input("What action did you take? (Refunded, Called, Sent Replacement, etc..): ")
		score= input("Customer Satisfaction Score (1-5): ")
		log_interaction(name, order, issue, action, score)
	elif choice == '2':
		filePath= input("Enter chat log file name: ")
		parse_chat(filePath)
	elif choice == '3':
		print("Exiting.. Have a sweet support day!")
		break
