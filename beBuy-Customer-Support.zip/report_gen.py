from fpdf import FPDF
import csv
from datetime import datetime

def make_report(csvf='interactions.csv', pdff='report.pdf'):
    pdf = FPDF()
    pdf.add_page()
    pdf.set_font("Arial", size=14)
    pdf.cell(200, 10, txt="beBuy Support Report", ln=True, align='C')
    pdf.set_font("Arial", size=10)
    pdf.cell(200, 10, txt=f"Date: {datetime.now().strftime('%Y-%m-%d')}", ln=True, align='C')
    pdf.ln(10)

    try:
        with open(csvf, newline='') as f:
            r = csv.reader(f)
            for row in r:
                for i in row:
                    pdf.cell(40, 10, i, 1)
                pdf.ln()
        pdf.output(pdff)
    except FileNotFoundError:
        print(f"{csvf} not found.")
