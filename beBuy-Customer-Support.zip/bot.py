from telegram import Update
from telegram.ext import ApplicationBuilder, ContextTypes, MessageHandler, filters
from log import log
from crm import load, get_name
from chat_log import chat
import re

TOKEN = "7583650669:AAHbr-vQWPIPd9FtGc0BS6sKKP-OFYaMm5A"
crm_data = load()

async def reply(update: Update, context: ContextTypes.DEFAULT_TYPE):
    try:
        txt = update.message.text
        usr = update.message.from_user
        oid = "Unknown"
        cat = "Gen"
        act = "Telegram"
        rate = 5

        m = re.search(r"(BBY\\d+)", txt)
        if m:
            oid = m.group(1)

        tl = txt.lower()
        if "refund" in tl:
            cat = "Refund"
        elif "late" in tl or "not delivered" in tl:
            cat = "Delay"
        elif "broken" in tl or "damaged" in tl:
            cat = "Issue"

        nm = get_name(oid, crm_data)
        if nm == "Unknown":
            nm = usr.first_name or "Unknown"

        log(nm, oid, cat, act, rate)
        chat(nm, txt)

        await update.message.reply_text(f"Hey {nm}, we got your msg about order {oid}")
    except Exception as e:
        await update.message.reply_text(f"Error: {e}")

def main():
    app = ApplicationBuilder().token(TOKEN).build()
    app.add_handler(MessageHandler(filters.TEXT & (~filters.COMMAND), reply))
    print("Bot live...")
    app.run_polling()

if __name__ == "__main__":
    main()
