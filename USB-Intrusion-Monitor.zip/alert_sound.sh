#!/bin/bash 
aplay /usr/share/sounds/alsa/Front_Center.wav

